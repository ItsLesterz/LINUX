package Semana_5;

public enum TipoCuenta {
    AHORROS, CHEQUE;

}
