/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Daniel
 */
public class FuncionesRecursivas {
    public static void print(int numero){
        if(numero>1)
            print(numero-1);
        System.out.println(numero);
    }
    
    public static void printMismo(int numero, int repetir){
        if(repetir>0){
            System.out.println(numero);
            printMismo(numero,repetir-1);
        }
    }
    
    public static int sumaUp(int numero){
        if(numero>=1)
            return sumaUp(numero-1)+numero;
        return 0;
    }
    
    public static int sumaDown(int numero){
        return sumaDown(numero,0);
    }
    
    private static int sumaDown(int numero, int suma){
        if(numero>=1)
            return sumaDown(numero-1,suma+numero);
        return suma;
    }
    
    public static int potUp(int base, int exponente){
        if(exponente>0)
            return potUp(base, exponente-1)*base;
        return 1;
    }
    
    public static int potDown(int base, int exponente){
        return potDown(base, exponente, 1);
    }
    
    private static int potDown(int base, int exponente, int producto){
        if(exponente>0)
            return potDown(base, exponente-1,producto*base);
        return producto;
    }
    
    public static boolean esPalindromo(String palabra){
        return esPalindromo(palabra,0,palabra.length()-1);
    }
    
    private static boolean esPalindromo(String word, int inicio, int fin){
        if(inicio<fin){
            if(word.charAt(inicio)==word.charAt(fin))
                return esPalindromo(word, inicio+1, fin-1);
            return false;
        }
        return true;
    }
    
    public static void piramide(int fila, String simbolo){
        if(fila>0){
            System.out.println(simbolo);
            piramide(fila-1,simbolo+"*");
        }
    }
    
    public static int fibonacci(){
        return fibonacci(0,1);
    }
    
    private static int fibonacci(int x, int y){
        if(0<y){
            System.out.print(x+", ");
            return fibonacci(y,x+y);
        }return 0;
    }
}
