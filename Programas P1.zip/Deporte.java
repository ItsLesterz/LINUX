package javatickets;

public enum Deporte {
    FUTBOL,TENIS,RUGBY,BASEBALL;
}
