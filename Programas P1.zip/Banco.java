package Semana_5;

import java.util.ArrayList;


public class Banco {

    // Atributos
    int indice = 0;
    TipoCuenta tipo;
    private static ArrayList<CuentaBancaria> cuentas;

    public static boolean search(int numeroCuenta, int indice) {
       if (indice == cuentas.size()) {
           if (cuentas.get(indice).getNumCuenta() == numeroCuenta) {
               System.out.println(cuentas.get(indice).toString());
               return true;
           } else {
               System.out.println(cuentas.get(indice).toString());
               search(numeroCuenta, indice + 1);
           }
       }
       return false;
    }

    public static void add(int numeroCuenta, String nombre, TipoCuenta tipoCuenta) {
        if (!search(numeroCuenta,0)) {
            if (tipoCuenta == TipoCuenta.AHORROS) {
                cuentas.add(new CuentaAhorro(numeroCuenta, nombre, 0));
            }
        }
    }

    public static void evalDeactivations(int indice) {
        if (indice < cuentas.size()) {
            if (cuentas.get(indice) instanceof CuentaAhorro) {
                ((CuentaAhorro) cuentas.get(indice)).desactivar();
            } else {
                evalDeactivations(indice + 1);
            }
        }
    }

    public static void applyInterests() {
        for (int i = 0; i < cuentas.size(); i++) {
            if (cuentas.get(i) instanceof CuentaPlazoFijo) {
                cuentas.get(i).deposito(cuentas.get(i).getSaldo() * 0.01);
            }
        }
    }

    public static void transfer(int numeroCuentaOrigen, int numeroCuentaDestino, double cantidad) {
        for (int i = 0; i < cuentas.size(); i++) {
            if (cuentas.get(i).getNumCuenta() == numeroCuentaOrigen && cuentas.get(i).getNumCuenta() == numeroCuentaDestino) {
                String cuenta1 = cuentas.get(i).toString();
                String cuenta2 = cuentas.get(i + 1).toString();
                cuentas.get(i).retiro(cantidad);
                cuentas.get(i + 1).deposito(cantidad);
                System.out.println("Transferencia realizada de " + cuenta1 + " a " + cuenta2);
            }
        }
    }

}


