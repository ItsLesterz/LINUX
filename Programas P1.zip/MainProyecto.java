package javatickets;

public class MainProyecto {

    public static void main(String[] args) {
        
        JavaTickets ventana = new JavaTickets();
        
        ventana.getBounds();

    }
    
}
