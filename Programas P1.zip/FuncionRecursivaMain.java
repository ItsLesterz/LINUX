
import java.util.Scanner;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author Daniel
 */
public class FuncionRecursivaMain {
    public static void main(String[] args) {
        Scanner read = new Scanner(System.in);
        int opcion=0;
         while(opcion!=9){
        System.out.println("\n\n*****FUNCIONES RECURSIVAS*****\n1. printMismo\t2. SumaUp\n3. SumaDown"
                + "\t4. PotenciaUp\n5. PotenciaDown\t6. esPalindromo\n7. Piramide\t8. Fibonacci\n"
                + "9. Salir");
        opcion = read.nextInt();
        switch(opcion){
            case 1:
                FuncionesRecursivas.print(5);
                break;
                
            case 2:
                FuncionesRecursivas.sumaUp(5);
                break;
                
            case 3:
                FuncionesRecursivas.sumaDown(5);
                break;
                
            case 4:
                System.out.println("Base: 5\tExponente: 4");
                FuncionesRecursivas.potUp(5,4);
                break;
                
            case 5:
                System.out.println("Base: 5\tExponente: 4");
                FuncionesRecursivas.potDown(5,4);
                break;
                
            case 6:
                System.out.println("Palabra: hannah");
                String es = ((FuncionesRecursivas.esPalindromo("hannah")) == true)? "si es palindromo":"no es";
                System.out.println(es);
                break;
                
            case 7:
                System.out.println("Ingrese la cantidad de filas: ");
                int filas=read.nextInt();
                FuncionesRecursivas.piramide(filas, "*");
                break;
                
            case 8:
                FuncionesRecursivas.fibonacci();
                break;
                
            case 9:
                System.out.println("Gracias por utilizar el programa!!");
                break;
        }
        }
    }
}
