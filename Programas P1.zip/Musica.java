/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tareas;

import java.io.Serializable;

/**
 *
 * @author xavie
 */
public class Musica implements Serializable {
    
    private static final long serialVersionUID=1L;
    //Es una especie de Id (Identificador) es para cuando se lea y sepamos de quien es
    
    
    private String genero;
    private String autor;
    private int duracion;
    private double precio;

    public Musica(String genero, String autor, int duracion, double precio) {
        this.genero = genero;
        this.autor = autor;
        this.duracion = duracion;
        this.precio = precio;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public String getAutor() {
        return autor;
    }

    public void setAutor(String autor) {
        this.autor = autor;
    }

    public int getDuracion() {
        return duracion;
    }

    public void setDuracion(int duracion) {
        this.duracion = duracion;
    }

    public double getPrecio() {
        return precio;
    }

    public void setPrecio(double precio) {
        this.precio = precio;
    }
    
    
    
    
    
}
