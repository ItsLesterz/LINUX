
package com.mycompany.examen1parcialkennethreyes;

import java.util.Scanner;

public class Ficotec {

    public static void main(String[] args) {
        Scanner read = new Scanner(System.in).useDelimiter("\n");
        Banco bnc = new Banco();
        int opcion;
        
        do {
            System.out.println("\n****FICOTEC****\n1. Agregar Cuenta\n2. Desactivar Cuenta\n3. Aplicar Intereses\n4. Transferir\n5. Salir");
            opcion = read.nextInt();
            switch(opcion){
                case 1:
                    System.out.println("Ingrese su numero de cuenta: ");
                    int num = read.nextInt();
                    System.out.println("Ingrese su nombre: ");
                    String cliente = read.next();
                    System.out.println("Ingrese el tipo de cuenta: ");
                    String tipo = read.next();
                    bnc.add(num, cliente, tipo);
                    break;
                    
                case 2:
                    bnc.evalDeactivations();
                    break;
                    
                case 3:
                    bnc.applyInterests();
                    break;
                    
                case 4:
                    System.out.println("Igrese el numero de cuenta local: ");
                    int num1 = read.nextInt();
                    System.out.println("Ingrese el numero de cuenta a transferir: ");
                    int num2 = read.nextInt();
                    System.out.println("Ingrese el monto a transferir: ");
                    double monto = read.nextDouble();
                    bnc.transfer(num1, num2, monto);
                    break;
                    
                case 5:
                    break;
                    
                default:
                    System.out.println("Opcion no valida!");
                    break;
            }
        } while (opcion != 5);
    }
}
