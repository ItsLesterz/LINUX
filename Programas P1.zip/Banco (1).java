
package com.mycompany.examen1parcialkennethreyes;

import java.util.ArrayList;

/**
 *
 * @author Daniel
 */
public class Banco {
    ArrayList <CuentaBancaria> cuentas = new ArrayList();
    
    public CuentaBancaria search(int nc, int indice){
        if(indice < cuentas.size()){
            if(cuentas.get(indice).getNumeroCuenta() == nc)
                return cuentas.get(indice);
            return search(nc, indice+1);
        }
        return null;
    }
    
    public void add (int num, String cliente, String tipo){
        if(search(num, 0) != null){
            if(tipo.equals("AHORRO")){
                CuentaAhorro acc = new CuentaAhorro(num, cliente);
                cuentas.add(acc);
            }else if(tipo.equals("CHEQUE")){
                CuentaPlazoFijo acc = new CuentaPlazoFijo(num, cliente);
                cuentas.add(acc);
            }
        }
    }
    
    public void evalDeactivations(){
        int i = 0;
        if(cuentas.get(i) instanceof CuentaAhorro){
            CuentaAhorro ca = new CuentaAhorro(cuentas.get(i).getNumeroCuenta(), cuentas.get(i).getNombreC());
            ca.desactivar();
        }else
            i++;
    }
    
    public void applyInterests(double monto){
        for(CuentaBancaria account: cuentas){
            if(account instanceof CuentaPlazoFijo){
                account.deposito(account.getSaldo()*((CuentaPlazoFijo) account).getTasa());
            }
        }
    }
    
    public boolean transfer(int nc1, int nc2, double monto){
        for(CuentaBancaria account: cuentas){
            
        }
        return false;
    }
}
