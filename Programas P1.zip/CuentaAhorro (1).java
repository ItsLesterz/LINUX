/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.examen1parcialkennethreyes;

import java.util.Calendar;

/**
 *
 * @author Daniel
 */
public class CuentaAhorro extends CuentaBancaria{
    private Calendar fecha;
    private boolean estado;
    
    public CuentaAhorro(int numeroC, String name){
        super(numeroC, name);
        fecha = Calendar.getInstance();
        estado = true;
    }
    
    @Override
    public double deposito(double m){
        if(estado == true){
            fecha = Calendar.getInstance();
            return super.deposito(m);
        }else{
            estado = true;
            fecha = Calendar.getInstance();
            return super.deposito(m*0.9);
        }
    }

    @Override
    public boolean retiro(double monto){
        if(estado == true){
            if(monto < saldo){
                saldo-=monto;
                return true;
            }
        }else{
            estado = true;
            return true;
        }
            return false;
    }

    public final boolean desactivar(){
        Calendar hoy = Calendar.getInstance();
        hoy.add(Calendar.MONTH, -6);
        if(hoy.before(fecha)){
            estado = false;
            return true;
        }
        return false;
    }
    
    public String estado(){
        if(estado == true)
            return "Activa";
        return "Desactivada";
    }
    
    @Override
    public String toString(){
        return super.toString()+" Estado de la cuenta: "+estado();
    }
}
