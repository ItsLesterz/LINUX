package Semana_5;

public final class CuentaPlazoFijo extends CuentaBancaria {

    // Atributos
    private double intereses;
    private static final double TASA = 0.01;

    // Constructor
    public CuentaPlazoFijo(int numCuenta, String nombreC, double saldo, double intereses) {
        super(numCuenta, nombreC, saldo);
        this.intereses = saldo * TASA;

    }

    @Override
    public boolean retiro(double retiro) {
        if (retiro <= intereses) {
            intereses -= retiro;
            return true;
        }
        return false;
    }
}
