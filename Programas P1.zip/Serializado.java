/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tareas;

import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutputStream;

public class Serializado {

    /*
        Metodo de Almacenamiento
       Serializacion es convertir algo de java en sucession de byte.
        
        Tipos de Api
        1.ObjectOutputStream
        -construye un flujo de datos desde dentro y afuera.
        2.writeObject
        -es escribir esos byte
        1.ObjectInputStream 
        -Lo mismo pero alrevez
        2.readObject
        -lee los bytes
        
        
        Tenemos que hacer que la clase sea serealizable, es decir que debe de contener el
        
        implements Seriazable y lo importamos
        
        y hace que se pueda meter en un fichero y si no esta no se puede
    
    
     Metodo de Almacenamiento
       Serializacion es convertir algo de java en sucession de byte.
        
        Tipos de Api
        1.ObjectOutputStream
        -construye un flujo de datos desde dentro y afuera.
        2.writeObject
        -es escribir esos byte
        1.ObjectInputStream 
        -Lo mismo pero alrevez
        2.readObject
        -lee los bytes
    
    La serialización es un mecanismo para convertir el estado de un objeto en un flujo de bytes. 
    La deserialización es el proceso inverso en el que el flujo de bytes se utiliza para recrear el objeto Java real en la memoria. 
    Este mecanismo se utiliza para conservar el objeto.
     */
    public static void main(String[] args) {

        //creamos objeto
        Musica musica1 = new Musica("\nRock", "Franklin", 2, 800);
        Musica musica2 = new Musica("\nPop", "Tinoco", 1, 500);

        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream("D:\\Musica.drr"))) {
            //se escribe en el fichero
            oos.writeObject(musica1);
            oos.writeObject(musica2);
        } catch (IOException e) {
            System.out.println(e.getMessage());
        }

    }

}
