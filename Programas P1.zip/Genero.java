package javatickets;

public enum Genero {
    POP,ROCK,RAP,CLASICA,REGGEATON,OTRO;
}
