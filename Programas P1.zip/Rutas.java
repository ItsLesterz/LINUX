
package LabTc3;

public class Rutas {
    
}
