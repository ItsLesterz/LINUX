/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package tareas;

import java.io.EOFException;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.ObjectInputStream;


/**
 *
 * @author xavie
 */
public class SerializacionLeer {
    public static void main(String[] args) {
        
        //La misma con la que escribimos es con la que leemos no mas cambia el OUT A Input
        
        try(ObjectInputStream ois=new ObjectInputStream(new FileInputStream("D:\\Musica.drr"))){
            while(true){
                Musica mus=(Musica)ois.readObject();
                //Agarra un objecto y obligatoriamente
                System.out.println(mus.getGenero());
                 System.out.println(mus.getAutor());
                  System.out.println(mus.getDuracion());
                   System.out.println(mus.getPrecio());
                   //es lo mimso que un toString
                   //Se puede aplicar en arraylist,method  etc.
                
                
            }
        }catch(ClassNotFoundException e){
        }catch(EOFException e){  
        }catch(IOException E){
         //estas son opciones para salir
            
        }
    }
    
}
