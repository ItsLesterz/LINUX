
package com.mycompany.examen1parcialkennethreyes;

public abstract class CuentaBancaria {
    private int numeroCuenta;
    private String nombreC;
    protected double saldo;
    
    public CuentaBancaria(int numCuenta, String nombre){
        this.numeroCuenta = numCuenta;
        this.nombreC = nombre;
        saldo = 500;
    }

    public int getNumeroCuenta() {
        return numeroCuenta;
    }

    public void setNumeroCuenta(int numeroCuenta) {
        this.numeroCuenta = numeroCuenta;
    }

    public String getNombreC() {
        return nombreC;
    }

    public void setNombreC(String nombreC) {
        this.nombreC = nombreC;
    }

    public double getSaldo() {
        return saldo;
    }

    public void setSaldo(double saldo) {
        this.saldo = saldo;
    }
    
    public double deposito(double m){
        return saldo+=m;
    }
    
    public abstract boolean retiro(double m);
    
    @Override
    public String toString(){
        return "Numero de cuenta: "+numeroCuenta+", Nombre de Cliente: "+nombreC+", Saldo: "+saldo+"Lps.";
    }
}
