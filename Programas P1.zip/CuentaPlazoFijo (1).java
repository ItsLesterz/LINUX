/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.examen1parcialkennethreyes;

/**
 *
 * @author Daniel
 */
final class CuentaPlazoFijo extends CuentaBancaria{
    private double intereses;
    private static final double tasa = 0.08;
    
    public CuentaPlazoFijo(int numCuenta, String name){
        super(numCuenta, name);
        intereses = 0;
    }
    public double getTasa(){
        return tasa;
    }
    @Override
    public boolean retiro(double m){
       if(intereses <= m){
           intereses-=m;
           return true;
       }else
           return false;
    }
    
    @Override
    public String toString(){
        return super.toString()+" Intereses: "+intereses;
    }
}
